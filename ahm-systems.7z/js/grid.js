$(document).ready(function() {

    // Click event binding on a links in the grid
    $('a.tab-link').click(function(e) {
        // Remove the style class
        $('a.w--current').removeClass('w--current');

        // Add the style class to the clicked element
        let clickedElement = $(e.currentTarget);
        clickedElement.addClass('w--current');

        let gridIndex = clickedElement.data('w-tab');
        console.log(gridIndex);

        //Remove the content display
        $('div.w--tab-active').removeClass('w--tab-active');

        $('[data-w-tab="' + gridIndex + '"]').addClass('w--tab-active');
    })
})